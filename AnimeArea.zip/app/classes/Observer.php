<?php
/**
 * Created by PhpStorm.
 * User: amr
 * Date: 11/16/17
 * Time: 1:36 PM
 */

namespace App\classes;


interface Observer
{
    public function handle();
}