<?php
/**
 * Created by PhpStorm.
 * User: amr
 * Date: 11/15/17
 * Time: 6:27 AM
 */

namespace App\classes;


interface ProductService
{
     public function getCost();
     public function getDescription();
}