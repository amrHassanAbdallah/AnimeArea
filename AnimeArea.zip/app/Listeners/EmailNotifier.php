<?php
/**
 * Created by PhpStorm.
 * User: amr
 * Date: 11/16/17
 * Time: 11:42 AM
 */

namespace App\Listeners;


class EmailNotifier
{
    public function handle()
    {
        var_dump('fire off an emailllllllllll');
    }
}