@include('inc.headerFront')


<div class="content-wrapper">

    <div class="container">
        <div class="row pt120">
            <div class="col-lg-8 col-lg-offset-2">
                <div class="heading align-center mb60">
                    <h4 class="h1 heading-title">AnimeArea ^_^</h4>
                    <p class="heading-text">Buy Products, and we ship to you.
                    </p>
                </div>
            </div>
        </div>
    </div>
@include('inc.feedback')
    <!-- End Books products grid -->
    @yield('page')

</div>

@include('inc.footerFront')