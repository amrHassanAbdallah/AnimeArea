<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithoutMiddleware;

class customerMiddleWareTest extends TestCase
{
    /**
     * A basic test example.
     *
     * @return void
     */
   /* public function testAccessWithoutMemberShip()
    {
        $this->browse(function ($browser) {
            $browser->visit('/dashboard')
                -> seePageIs('/login');
        });

    }*/
}
