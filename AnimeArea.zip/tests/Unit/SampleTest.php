<?php
namespace Tests\Unit;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;

class SampleTest extends TestCase
{
    /**
     * A basic test example.
     *
     * @return void
     */

    //boolean to assert something
    public function testTrueAssertToTrue()
    {
        $this->assertTrue(true);
    }
}
